import React, { useState } from "react";

function Main() {
  return <h1>Main Page</h1>;
}

export default Main;
