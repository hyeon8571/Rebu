import styled from "styled-components";

const IconWrapper = styled.a``;
const Icon = styled.img`
`;

export default function ButtonIcon({ img }) {
  return <img src={img} />;
}
